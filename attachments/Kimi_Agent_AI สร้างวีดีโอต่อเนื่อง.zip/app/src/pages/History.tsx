import { useNavigate } from "react-router";
import { Film, History as HistoryIcon, Image as ImageIcon, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function History() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const list = trpc.studio.history.useQuery();
  const remove = trpc.studio.remove.useMutation({
    onSuccess: () => utils.studio.history.invalidate(),
  });

  return (
    <div className="mx-auto max-w-[1000px] px-4 md:px-8 py-8 md:py-12">
      <header className="space-y-2 mb-8">
        <p className="label-tech text-gel-pink">Archive</p>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
          ประวัติการออกแบบ
        </h1>
        <p className="text-muted-foreground text-sm">
          ชุดพร้อมต์ที่เคยสร้างไว้ — แตะเพื่อเปิดดูและคัดลอกอีกครั้ง
        </p>
      </header>

      {list.isLoading && (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-24 rounded-lg bg-secondary/60 animate-pulse"
            />
          ))}
        </div>
      )}

      {list.data && list.data.length === 0 && (
        <div className="border border-dashed border-border rounded-lg p-12 text-center space-y-4">
          <HistoryIcon className="h-8 w-8 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">
            ยังไม่มีประวัติ — ลองสร้างชุดพร้อมต์ชุดแรกของคุณ
          </p>
          <button
            onClick={() => navigate("/")}
            className="h-11 px-5 rounded-md bg-foreground text-background font-medium text-sm hover:bg-gel-cyan transition-colors"
          >
            ไปที่สตูดิโอ
          </button>
        </div>
      )}

      <div className="divide-y divide-border border-y border-border">
        {list.data?.map((g) => (
          <div
            key={g.id}
            className="group flex items-center gap-4 py-4 md:py-5 cursor-pointer"
            onClick={() => navigate(`/?g=${g.id}`)}
          >
            <div
              className={`h-11 w-11 shrink-0 rounded-md border flex items-center justify-center ${
                g.mode === "video"
                  ? "border-gel-pink/40 text-gel-pink"
                  : "border-gel-cyan/40 text-gel-cyan"
              }`}
            >
              {g.mode === "video" ? (
                <Film className="h-4 w-4" />
              ) : (
                <ImageIcon className="h-4 w-4" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-display font-semibold truncate">{g.title}</p>
              <p className="text-xs text-muted-foreground truncate mt-0.5">
                {g.logline || "—"}
              </p>
              <p className="label-tech text-muted-foreground/60 text-[9px] mt-1.5">
                {g.sceneCount} scenes · {g.aspectRatio} ·{" "}
                {new Date(g.createdAt).toLocaleDateString("th-TH", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (confirm(`ลบ "${g.title}" ออกจากประวัติ?`)) {
                  remove.mutate({ id: g.id });
                }
              }}
              className="h-11 w-11 shrink-0 rounded-md flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
              aria-label="ลบรายการ"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
