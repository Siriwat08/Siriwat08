import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Clapperboard,
  Copy,
  Film,
  Image as ImageIcon,
  Lightbulb,
  RefreshCcw,
  Upload,
  X,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import SceneCard, { useCopyFeedback } from "@/components/SceneCard";
import { fileToResizedDataUrl } from "@/lib/image";
import {
  ASPECT_OPTIONS,
  STYLE_OPTIONS,
  type GenerationMode,
  type SceneBundle,
  type ScenePrompt,
  type SourceType,
} from "@contracts/studio";

const LOADING_STEPS = [
  "กำลังอ่านไอเดียของคุณ…",
  "กำลังวางโครงเรื่องเป็นฉากๆ…",
  "กำลังเขียนพร้อมต์แต่ละฉาก…",
  "กำลังปรับความต่อเนื่องของเรื่อง…",
];

const SOURCE_OPTIONS: { value: SourceType; label: string; hint: string }[] = [
  { value: "idea", label: "จากไอเดีย", hint: "พิมพ์เรื่องที่จินตนาการไว้" },
  { value: "image", label: "จากรูปภาพ", hint: "อัปโหลดรูปเป็นฉากเปิด" },
  { value: "continue", label: "ต่อจากคลิปเดิม", hint: "เล่าต่อจากเรื่องที่มีอยู่" },
];

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="label-tech text-muted-foreground mb-2.5">{children}</p>
  );
}

export default function Home() {
  const [searchParams, setSearchParams] = useSearchParams();
  const historyId = Number(searchParams.get("g") ?? 0) || null;

  // ---- form state ----
  const [mode, setMode] = useState<GenerationMode>("video");
  const [sourceType, setSourceType] = useState<SourceType>("image");
  const [idea, setIdea] = useState("");
  const [extraDetails, setExtraDetails] = useState("");
  const [sceneCount, setSceneCount] = useState(4);
  const [style, setStyle] = useState<string>("cinematic");
  const [aspectRatio, setAspectRatio] = useState("16:9");
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ---- result state ----
  const [result, setResult] = useState<(SceneBundle & { id?: number }) | null>(
    null,
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);
  const { copiedKey, copy } = useCopyFeedback();

  const utils = trpc.useUtils();

  const generate = trpc.studio.generate.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setErrorMsg(null);
      utils.studio.history.invalidate();
    },
    onError: (err) => {
      setErrorMsg(err.message);
    },
  });

  // ---- load a past generation via ?g=<id> ----
  const historyQuery = trpc.studio.getById.useQuery(
    { id: historyId ?? 0 },
    { enabled: historyId !== null, retry: false },
  );

  useEffect(() => {
    if (!historyQuery.data) return;
    const g = historyQuery.data;
    setResult({
      id: g.id,
      title: g.title,
      logline: g.logline ?? "",
      scenes: (g.scenesJson as ScenePrompt[]) ?? [],
    });
    setMode(g.mode as GenerationMode);
    setSourceType(g.sourceType as SourceType);
    setIdea(g.idea ?? "");
    setStyle(g.style ?? "cinematic");
    setAspectRatio(g.aspectRatio ?? "16:9");
    setSceneCount(g.sceneCount);
    setErrorMsg(null);
  }, [historyQuery.data]);

  // ---- staged loading message ----
  useEffect(() => {
    if (!generate.isPending) return;
    setLoadingStep(0);
    const t = setInterval(
      () => setLoadingStep((s) => Math.min(s + 1, LOADING_STEPS.length - 1)),
      2400,
    );
    return () => clearInterval(t);
  }, [generate.isPending]);

  const canSubmit = useMemo(() => {
    if (generate.isPending) return false;
    if (sourceType === "image") return Boolean(imageDataUrl) || idea.trim().length > 0;
    return idea.trim().length > 0;
  }, [generate.isPending, sourceType, imageDataUrl, idea]);

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const dataUrl = await fileToResizedDataUrl(file);
      setImageDataUrl(dataUrl);
      setSourceType("image");
    } catch {
      setErrorMsg("อ่านไฟล์รูปภาพไม่สำเร็จ กรุณาลองไฟล์อื่น");
    }
  };

  const submit = () => {
    setErrorMsg(null);
    setResult(null);
    if (historyId) setSearchParams({}, { replace: true });
    generate.mutate({
      mode,
      sourceType,
      idea:
        idea.trim() ||
        "สร้างเรื่องราวต่อเนื่องจากรูปภาพที่แนบมา โดยวิเคราะห์องค์ประกอบในภาพเป็นจุดเริ่มต้น",
      sceneCount,
      style,
      aspectRatio,
      extraDetails: extraDetails.trim() || undefined,
      imageDataUrl: sourceType === "image" ? (imageDataUrl ?? undefined) : undefined,
    });
  };

  const copyAll = () => {
    if (!result) return;
    const text = result.scenes
      .map(
        (s) =>
          `===== SCENE ${String(s.scene).padStart(2, "0")} — ${s.titleTh} =====\n${s.descriptionTh}\n\n[EN PROMPT]\n${s.promptEn}\n\n[TH คำสั่ง]\n${s.promptTh}`,
      )
      .join("\n\n\n");
    copy("all", `🎬 ${result.title}\n${result.logline}\n\n${text}`);
  };

  const ideaLabel =
    sourceType === "continue"
      ? "เล่าเรื่องเดิมและสิ่งที่อยากให้เกิดต่อ"
      : sourceType === "image"
        ? "บรรยายเพิ่มเติม (ไม่บังคับ)"
        : "ไอเดียเรื่องราวของคุณ";

  const ideaPlaceholder =
    sourceType === "continue"
      ? "เช่น คลิปเดิมเป็นรถกระบะขนส่งแล่นฝ่าฝนและน้ำท่วม อยากให้ต่อไปรถทะลุออกจากน้ำแล้วขับขึ้นสะพานตอนฟ้าสาง…"
      : sourceType === "image"
        ? "เช่น อยากให้รถคันนี้แล่นต่อไปเรื่อยๆ จนเจอสายรุ้งตอนฝนหยุด…"
        : "เช่น ขบวนรถกระบะขนส่งแล่นฝ่าพายุฝนกลางถนนน้ำท่วม ไปส่งของให้ทันเวลา…";

  return (
    <div className="mx-auto max-w-[1400px] px-4 md:px-8 py-6 md:py-10">
      <div className="grid gap-10 lg:grid-cols-[380px_minmax(0,1fr)] xl:grid-cols-[420px_minmax(0,1fr)]">
        {/* ============ DIRECTOR CONSOLE ============ */}
        <section className="lg:sticky lg:top-24 self-start space-y-7">
          <header className="space-y-2">
            <p className="label-tech text-gel-pink">Director Console</p>
            <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight leading-tight">
              ออกแบบพร้อมต์
              <br />
              <span className="gel-text-gradient">เป็นฉากต่อเนื่อง</span>
            </h1>
          </header>

          {/* mode */}
          <div>
            <SectionLabel>01 · อยากสร้างอะไร</SectionLabel>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { v: "image", label: "รูปภาพ", icon: ImageIcon },
                  { v: "video", label: "วิดีโอ", icon: Film },
                ] as const
              ).map((o) => (
                <button
                  key={o.v}
                  onClick={() => setMode(o.v)}
                  className={`h-12 rounded-md border flex items-center justify-center gap-2 font-display font-semibold transition-colors ${
                    mode === o.v
                      ? "border-gel-cyan bg-gel-cyan/10 text-gel-cyan"
                      : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <o.icon className="h-4 w-4" />
                  {o.label}
                </button>
              ))}
            </div>
          </div>

          {/* source type */}
          <div>
            <SectionLabel>02 · เริ่มจาก</SectionLabel>
            <div className="grid grid-cols-3 gap-2">
              {SOURCE_OPTIONS.map((o) => (
                <button
                  key={o.value}
                  onClick={() => setSourceType(o.value)}
                  title={o.hint}
                  className={`min-h-11 px-2 py-2 rounded-md border text-[13px] font-medium transition-colors ${
                    sourceType === o.value
                      ? "border-gel-pink bg-gel-pink/10 text-gel-pink"
                      : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>

          {/* image upload */}
          {sourceType === "image" && (
            <div>
              <SectionLabel>03 · รูปภาพต้นฉบับ</SectionLabel>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0])}
              />
              {imageDataUrl ? (
                <div className="relative rounded-lg overflow-hidden border border-border">
                  <img
                    src={imageDataUrl}
                    alt="รูปต้นฉบับ"
                    className="w-full max-h-56 object-cover"
                  />
                  <button
                    onClick={() => {
                      setImageDataUrl(null);
                      if (fileInputRef.current) fileInputRef.current.value = "";
                    }}
                    className="absolute top-2 right-2 h-9 w-9 rounded-md bg-black/70 border border-border flex items-center justify-center hover:bg-black"
                    aria-label="ลบรูป"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full min-h-28 rounded-lg border border-dashed border-border hover:border-gel-cyan/60 transition-colors flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground p-4"
                >
                  <Upload className="h-5 w-5" />
                  <span className="text-sm">แตะเพื่ออัปโหลดรูปภาพ</span>
                  <span className="text-xs text-muted-foreground/60">
                    AI จะวิเคราะห์รูปเป็นฉากเปิดเรื่อง
                  </span>
                </button>
              )}
            </div>
          )}

          {/* idea */}
          <div>
            <SectionLabel>
              {sourceType === "image" ? "04" : "03"} · {ideaLabel}
            </SectionLabel>
            <textarea
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder={ideaPlaceholder}
              rows={4}
              className="w-full rounded-lg bg-card border border-border px-3.5 py-3 text-sm leading-relaxed placeholder:text-muted-foreground/50 focus:outline-none focus:border-gel-cyan/60 resize-y min-h-24"
            />
          </div>

          {/* scene count */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="label-tech text-muted-foreground">
                {sourceType === "image" ? "05" : "04"} · จำนวนฉาก
              </span>
              <span className="font-display text-lg font-bold text-gel-lemon">
                {sceneCount}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              value={sceneCount}
              onChange={(e) => setSceneCount(Number(e.target.value))}
              className="w-full h-11 accent-[#e5ff21] cursor-pointer"
              aria-label="จำนวนฉาก"
            />
          </div>

          {/* style */}
          <div>
            <SectionLabel>
              {sourceType === "image" ? "06" : "05"} · สไตล์ภาพ
            </SectionLabel>
            <div className="flex flex-wrap gap-1.5">
              {STYLE_OPTIONS.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setStyle(s.value)}
                  className={`min-h-11 px-3 rounded-full border text-[13px] transition-colors ${
                    style === s.value
                      ? "border-foreground bg-foreground text-background font-medium"
                      : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* aspect */}
          <div>
            <SectionLabel>
              {sourceType === "image" ? "07" : "06"} · อัตราส่วนภาพ
            </SectionLabel>
            <div className="grid grid-cols-4 gap-1.5">
              {ASPECT_OPTIONS.map((a) => (
                <button
                  key={a.value}
                  onClick={() => setAspectRatio(a.value)}
                  className={`min-h-11 rounded-md border font-mono text-xs transition-colors ${
                    aspectRatio === a.value
                      ? "border-gel-lemon bg-gel-lemon/10 text-gel-lemon"
                      : "border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {a.value}
                </button>
              ))}
            </div>
          </div>

          {/* advanced */}
          <div>
            <button
              onClick={() => setShowAdvanced((v) => !v)}
              className="flex items-center gap-1.5 label-tech text-muted-foreground hover:text-foreground min-h-11 transition-colors"
            >
              <ChevronDown
                className={`h-3.5 w-3.5 transition-transform ${showAdvanced ? "rotate-180" : ""}`}
              />
              รายละเอียดเพิ่มเติม
            </button>
            {showAdvanced && (
              <textarea
                value={extraDetails}
                onChange={(e) => setExtraDetails(e.target.value)}
                placeholder="เช่น โทนสีฟ้า-เทา, แสงไฟหน้ารถสะท้อนน้ำ, มุมกล้องต่ำ, อารมณ์ตึงเครียด…"
                rows={3}
                className="w-full rounded-lg bg-card border border-border px-3.5 py-3 text-sm leading-relaxed placeholder:text-muted-foreground/50 focus:outline-none focus:border-gel-cyan/60 resize-y"
              />
            )}
          </div>

          {/* submit */}
          <button
            onClick={submit}
            disabled={!canSubmit}
            className={`w-full h-14 rounded-md font-display font-bold text-base flex items-center justify-center gap-2 transition-all ${
              canSubmit
                ? "bg-foreground text-background hover:bg-gel-cyan"
                : "bg-secondary text-muted-foreground cursor-not-allowed"
            }`}
          >
            {generate.isPending ? (
              <>
                <RefreshCcw className="h-4 w-4 animate-spin" />
                กำลังออกแบบ…
              </>
            ) : (
              <>
                <Clapperboard className="h-5 w-5" />
                ออกแบบพร้อมต์ {sceneCount} ฉาก
              </>
            )}
          </button>
        </section>

        {/* ============ OUTPUT ============ */}
        <section className="min-w-0">
          {/* error */}
          {errorMsg && (
            <div className="mb-6 rounded-lg border border-destructive/50 bg-destructive/10 px-4 py-3.5 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-destructive">
                  สร้างพร้อมต์ไม่สำเร็จ
                </p>
                <p className="text-sm text-muted-foreground mt-1">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* loading */}
          {generate.isPending && (
            <div className="border border-border rounded-lg overflow-hidden">
              <div className="relative h-1 bg-secondary overflow-hidden">
                <div className="absolute inset-y-0 w-1/2 bg-gel-cyan scanline" />
              </div>
              <div className="p-8 md:p-12 space-y-6">
                <div className="flex items-center gap-3">
                  <span className="h-2.5 w-2.5 rounded-full bg-gel-pink pulse-dot" />
                  <p className="label-tech text-gel-cyan">Generating</p>
                </div>
                <p className="font-display text-2xl md:text-3xl font-semibold">
                  {LOADING_STEPS[loadingStep]}
                </p>
                <div className="space-y-3">
                  {Array.from({ length: Math.min(sceneCount, 4) }).map(
                    (_, i) => (
                      <div
                        key={i}
                        className="h-16 rounded-md bg-secondary/60 animate-pulse"
                        style={{ animationDelay: `${i * 150}ms` }}
                      />
                    ),
                  )}
                </div>
              </div>
            </div>
          )}

          {/* empty state */}
          {!generate.isPending && !result && !errorMsg && (
            <div className="border border-dashed border-border rounded-lg p-8 md:p-14 text-center space-y-6">
              <div className="mx-auto h-14 w-14 rounded-xl bg-secondary flex items-center justify-center">
                <Lightbulb className="h-6 w-6 text-gel-lemon" />
              </div>
              <div className="space-y-2">
                <h2 className="font-display text-2xl font-semibold">
                  เริ่มจากแผงด้าน{typeof window !== "undefined" && window.innerWidth >= 1024 ? "ซ้าย" : "บน"}
                </h2>
                <p className="text-muted-foreground text-sm leading-relaxed max-w-md mx-auto">
                  เลือกว่าจะสร้างรูปภาพหรือวิดีโอ ใส่ไอเดียหรืออัปโหลดรูปภาพ
                  แล้วกด "ออกแบบพร้อมต์" — AI จะเขียนชุดคำสั่งเป็นฉากๆ
                  ที่ต่อเนื่องกันให้ พร้อมปุ่มคัดลอกไปใช้ต่อทันที
                </p>
              </div>
              <div className="grid sm:grid-cols-3 gap-3 text-left max-w-2xl mx-auto">
                {[
                  {
                    n: "A",
                    t: "ใส่ไอเดียหรือรูป",
                    d: "เล่าเรื่องในหัว หรืออัปโหลดรูปตั้งต้น",
                  },
                  {
                    n: "B",
                    t: "AI แตกเป็นฉาก",
                    d: "ได้พร้อมต์ EN + คำสั่ง TH ครบทุกฉาก",
                  },
                  {
                    n: "C",
                    t: "คัดลอกไปสั่งต่อ",
                    d: "วางในแชท AI สร้างภาพ/วิดีโอทีละฉาก",
                  },
                ].map((s) => (
                  <div key={s.n} className="border border-border rounded-lg p-4">
                    <p className="font-mono text-gel-pink text-sm font-semibold">
                      {s.n}
                    </p>
                    <p className="font-display font-semibold mt-1.5">{s.t}</p>
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                      {s.d}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* result */}
          {!generate.isPending && result && (
            <div>
              <div className="pb-6 md:pb-8 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`label-tech px-2.5 py-1.5 rounded-sm border ${
                      mode === "video"
                        ? "border-gel-pink/50 text-gel-pink"
                        : "border-gel-cyan/50 text-gel-cyan"
                    }`}
                  >
                    {mode === "video" ? "Video" : "Image"} ·{" "}
                    {result.scenes.length} scenes
                  </span>
                  <span className="label-tech px-2.5 py-1.5 rounded-sm border border-border text-muted-foreground">
                    {aspectRatio}
                  </span>
                  {historyId && (
                    <button
                      onClick={() => {
                        setResult(null);
                        setSearchParams({}, { replace: true });
                      }}
                      className="label-tech px-2.5 py-1.5 rounded-sm border border-border text-muted-foreground hover:text-foreground transition-colors"
                    >
                      ปิดรายการจากประวัติ
                    </button>
                  )}
                </div>
                <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight leading-tight">
                  {result.title}
                </h2>
                {result.logline && (
                  <p className="text-muted-foreground leading-relaxed max-w-2xl">
                    {result.logline}
                  </p>
                )}
                <button
                  onClick={copyAll}
                  className={`h-11 px-4 rounded-md flex items-center gap-2 font-medium text-sm border transition-colors ${
                    copiedKey === "all"
                      ? "border-gel-lemon text-gel-lemon"
                      : "border-border hover:border-foreground/40"
                  }`}
                >
                  {copiedKey === "all" ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                  {copiedKey === "all" ? "คัดลอกแล้ว" : "คัดลอกพร้อมต์ทั้งหมด"}
                </button>

                {mode === "video" && (
                  <div className="rounded-lg border border-gel-cyan/30 bg-gel-cyan/5 px-4 py-3.5 text-sm leading-relaxed text-foreground/80">
                    <span className="label-tech text-gel-cyan block mb-1.5">
                      วิธีใช้โหมดวิดีโอ
                    </span>
                    สร้างทีละคลิปตามลำดับฉาก — ฉากที่ 1 ใช้คู่กับ
                    <strong>รูปภาพต้นฉบับ</strong> ส่วนฉากที่ 2 เป็นต้นไป
                    ให้ส่ง<strong>คลิปที่เพิ่งสร้างเสร็จ</strong>พร้อมวางคำสั่งของฉากนั้น
                    AI จะสร้างคลิปต่อเนื่องจากเฟรมสุดท้ายให้
                  </div>
                )}
              </div>

              <div>
                {result.scenes.map((scene, i) => (
                  <SceneCard
                    key={`${result.id ?? "new"}-${scene.scene}-${i}`}
                    scene={scene}
                    index={i}
                    copiedKey={copiedKey}
                    onCopy={copy}
                  />
                ))}
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
