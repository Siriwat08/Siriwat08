import { Clapperboard } from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="min-h-screen grain-overlay flex flex-col items-center justify-center px-6">
      <div className="w-full max-w-sm space-y-8 text-center">
        <div className="space-y-5">
          <div className="mx-auto h-14 w-14 rounded-xl bg-gel-cyan flex items-center justify-center">
            <Clapperboard className="h-7 w-7 text-black" strokeWidth={2.2} />
          </div>
          <div className="space-y-2">
            <p className="label-tech text-gel-pink">PromptWeaver</p>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              เข้าสู่สตูดิโอ
            </h1>
            <p className="text-sm text-muted-foreground leading-relaxed">
              เข้าสู่ระบบเพื่อให้ AI ออกแบบชุดพร้อมต์สร้างรูปภาพและวิดีโอ
              เป็นฉากต่อเนื่องสำหรับคุณ
            </p>
          </div>
        </div>
        <button
          className="w-full h-12 rounded-md bg-foreground text-background font-display font-semibold hover:bg-gel-cyan transition-colors"
          onClick={() => {
            window.location.href = getOAuthUrl();
          }}
        >
          เข้าสู่ระบบด้วย Kimi
        </button>
      </div>
    </div>
  );
}
