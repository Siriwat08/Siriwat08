import { type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router";
import { Clapperboard, History, LogOut, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LOGIN_PATH } from "@/const";

function BrandMark() {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <div className="relative h-8 w-8 rounded-md bg-gel-cyan flex items-center justify-center">
        <Clapperboard className="h-4 w-4 text-black" strokeWidth={2.2} />
        <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-gel-pink pulse-dot" />
      </div>
      <div className="leading-none">
        <div className="font-display font-bold text-[15px] tracking-tight">
          PromptWeaver
        </div>
        <div className="label-tech text-muted-foreground text-[9px] mt-1">
          Scene Prompt Studio
        </div>
      </div>
    </div>
  );
}

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 grain-overlay">
        <div className="h-10 w-10 rounded-lg bg-gel-cyan/20 flex items-center justify-center">
          <Clapperboard className="h-5 w-5 text-gel-cyan animate-pulse" />
        </div>
        <p className="label-tech text-muted-foreground">Loading studio…</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen grain-overlay flex flex-col">
        <header className="h-16 border-b border-border flex items-center px-5 md:px-8">
          <BrandMark />
        </header>
        <main className="flex-1 flex items-center justify-center px-6">
          <div className="max-w-md w-full text-center space-y-8">
            <div className="space-y-4">
              <p className="label-tech text-gel-pink">Lights · Camera · Prompt</p>
              <h1 className="font-display text-4xl md:text-5xl font-bold leading-[1.1] tracking-tight">
                ออกแบบพร้อมต์
                <br />
                <span className="gel-text-gradient">เป็นฉากต่อเนื่อง</span>
              </h1>
              <p className="text-muted-foreground leading-relaxed">
                ให้ AI ช่วยเขียนชุดคำสั่งสร้างรูปภาพหรือวิดีโอเป็นฉากๆ
                จากไอเดีย รูปภาพ หรือคลิปเดิมของคุณ
                แล้วนำไปวางในเครื่องมือสร้างภาพ/วิดีโอได้ทันที
              </p>
            </div>
            <button
              onClick={() => navigate(LOGIN_PATH)}
              className="w-full h-12 rounded-md bg-foreground text-background font-display font-semibold text-base hover:bg-gel-cyan transition-colors"
            >
              เข้าสู่ระบบด้วย Kimi เพื่อเริ่มสร้าง
            </button>
            <p className="text-xs text-muted-foreground/70">
              การสร้างพร้อมต์ใช้โควต้า AI ของเจ้าของเว็บไซต์
            </p>
          </div>
        </main>
      </div>
    );
  }

  const navItems = [
    { label: "สตูดิโอ", path: "/", icon: Sparkles },
    { label: "ประวัติ", path: "/history", icon: History },
  ];

  return (
    <div className="min-h-screen grain-overlay flex flex-col">
      <header className="h-16 border-b border-border flex items-center justify-between px-4 md:px-8 sticky top-0 z-40 bg-background/90 backdrop-blur">
        <Link to="/" aria-label="PromptWeaver home">
          <BrandMark />
        </Link>

        <nav className="flex items-center gap-1 md:gap-2">
          {navItems.map((item) => {
            const active =
              item.path === "/"
                ? location.pathname === "/"
                : location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`h-11 px-3 md:px-4 rounded-md flex items-center gap-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-secondary text-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <item.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </Link>
            );
          })}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="ml-1 h-11 w-11 flex items-center justify-center rounded-md hover:bg-secondary transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                <Avatar className="h-8 w-8 border border-border">
                  <AvatarFallback className="bg-gel-pink/15 text-gel-pink text-xs font-semibold">
                    {user.name?.charAt(0).toUpperCase() ?? "U"}
                  </AvatarFallback>
                </Avatar>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="font-medium truncate">{user.name ?? "-"}</div>
                <div className="text-xs text-muted-foreground font-normal truncate">
                  {user.email ?? ""}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={logout}
                className="cursor-pointer text-destructive focus:text-destructive"
              >
                <LogOut className="mr-2 h-4 w-4" />
                ออกจากระบบ
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border px-4 md:px-8 py-4 flex flex-col sm:flex-row gap-1 sm:items-center sm:justify-between">
        <p className="label-tech text-muted-foreground/60 text-[9px]">
          PromptWeaver · AI Scene Prompt Studio
        </p>
        <p className="text-xs text-muted-foreground/70">
          การสร้างพร้อมต์แต่ละครั้งใช้โควต้า AI ของเจ้าของเว็บไซต์
        </p>
      </footer>
    </div>
  );
}
