/**
 * Resize an uploaded image file to a compact JPEG data URL (max 1024px long edge)
 * so it can be sent to the vision model inside a tRPC payload.
 */
export function fileToResizedDataUrl(
  file: File,
  maxEdge = 1024,
  quality = 0.82,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("ไม่สามารถประมวลผลรูปภาพได้"));
        return;
      }
      ctx.drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("ไฟล์รูปภาพไม่ถูกต้อง"));
    };
    img.src = url;
  });
}
