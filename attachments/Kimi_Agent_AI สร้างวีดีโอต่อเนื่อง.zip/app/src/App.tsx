import { Routes, Route } from "react-router";
import AppShell from "@/components/AppShell";
import Home from "./pages/Home";
import History from "./pages/History";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <AppShell>
            <Home />
          </AppShell>
        }
      />
      <Route
        path="/history"
        element={
          <AppShell>
            <History />
          </AppShell>
        }
      />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
