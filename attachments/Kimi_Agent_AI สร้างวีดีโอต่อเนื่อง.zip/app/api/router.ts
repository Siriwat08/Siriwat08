import { authRouter } from "./auth-router";
import { studioRouter } from "./studio-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  studio: studioRouter,
});

export type AppRouter = typeof appRouter;
