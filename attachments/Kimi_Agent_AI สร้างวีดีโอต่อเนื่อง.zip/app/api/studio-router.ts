import { z } from "zod";
import { generateObject } from "ai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { TRPCError } from "@trpc/server";
import { and, desc, eq } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { generations } from "@db/schema";
import {
  listModels,
  classifyAiError,
  AiUnavailable,
  ContentRejected,
  AiMisconfigured,
  AiInvalidRequest,
  AiTransient,
} from "./lib/ai-client";
import type { SceneBundle } from "@contracts/studio";

const sceneSchema = z.object({
  scene: z.number().int().min(1),
  titleTh: z.string(),
  descriptionTh: z.string(),
  promptEn: z.string(),
  promptTh: z.string(),
  continuityNote: z.string().optional(),
});

const bundleSchema = z.object({
  title: z.string(),
  logline: z.string(),
  scenes: z.array(sceneSchema).min(1).max(12),
});

function getProvider() {
  const baseURL = process.env.KIMI_AGENTGW_BASE_URL;
  const apiKey = process.env.KIMI_AGENTGW_API_KEY;
  if (!baseURL || !apiKey) {
    throw new AiMisconfigured(
      "KIMI_AGENTGW_BASE_URL / KIMI_AGENTGW_API_KEY 未注入",
    );
  }
  return createOpenAICompatible({
    name: "kimi-gw",
    baseURL,
    apiKey,
    supportsStructuredOutputs: true,
  });
}

function toTrpcError(err: unknown): TRPCError {
  const classified = classifyAiError(err);
  if (classified instanceof AiUnavailable) {
    return new TRPCError({
      code: "FORBIDDEN",
      message:
        "โควต้าการใช้งาน AI ของเว็บไซต์หมดแล้ว กรุณาแจ้งเจ้าของเว็บไซต์เพื่อเติมโควต้า",
    });
  }
  if (classified instanceof ContentRejected) {
    return new TRPCError({
      code: "BAD_REQUEST",
      message: "เนื้อหาถูกระบบปฏิเสธ กรุณาปรับคำอธิบายใหม่แล้วลองอีกครั้ง",
    });
  }
  if (classified instanceof AiMisconfigured) {
    return new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "การตั้งค่าระบบ AI ผิดพลาด กรุณาแจ้งเจ้าของเว็บไซต์",
    });
  }
  if (classified instanceof AiTransient) {
    return new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "ระบบ AI ขัดข้องชั่วคราว กรุณารอสักครู่แล้วกดสร้างอีกครั้ง",
    });
  }
  if (classified instanceof AiInvalidRequest) {
    return new TRPCError({
      code: "BAD_REQUEST",
      message: "คำขอไม่ถูกต้อง กรุณาตรวจสอบข้อมูลที่กรอก",
    });
  }
  return new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: "สร้างพร้อมต์ไม่สำเร็จ กรุณาลองอีกครั้ง",
  });
}

const STYLE_LABEL: Record<string, string> = {
  cinematic: "cinematic photorealistic, dramatic film lighting",
  documentary: "documentary realism, natural light, handheld feel",
  anime: "Japanese anime style, detailed background art",
  cartoon3d: "3D animated movie style, Pixar-like rendering",
  fantasy: "epic fantasy, magical atmosphere, rich detail",
  "retro-film": "retro film look, analog grain, vintage color grading",
  cyberpunk: "cyberpunk neon, high contrast, futuristic city",
  watercolor: "watercolor painting, soft artistic strokes",
};

function buildSystemPrompt(input: {
  mode: "image" | "video";
  sourceType: "idea" | "image" | "continue";
  sceneCount: number;
  style: string;
  aspectRatio: string;
}): string {
  const styleEn = STYLE_LABEL[input.style] ?? input.style;
  const base = `คุณคือ "ผู้กำกับพร้อมต์" (Prompt Director) ระดับมืออาชีพ เชี่ยวชาญการเขียนพร้อมต์สำหรับ AI สร้างภาพและวิดีโอ (เช่น Midjourney, Kling, Runway, Veo) หน้าที่ของคุณคือแปลงไอเดียของผู้ใช้ให้กลายเป็น "ชุดพร้อมต์เป็นฉากๆ ที่ต่อเนื่องกัน" เหมือนสตอรี่บอร์ดภาพยนตร์

กฎสำคัญ:
- สไตล์ภาพรวมของทุกฉาก: ${styleEn}
- อัตราส่วนภาพ: ${input.aspectRatio}
- ทุกฉากต้องมีตัวละคร/บรรยากาศ/โทนสี/แสง ที่ "สม่ำเสมอ" กัน — ให้เขียนคำอธิบายตัวละครและฉากหลักซ้ำใน promptEn ของทุกฉากแบบเดิมทุกประการ เพื่อให้ AI สร้างภาพที่ตัวละครหน้าตาเหมือนเดิม
- promptEn: เขียนเป็นภาษาอังกฤษ ละเอียด ครอบคลุม องค์ประกอบภาพ แสง มุมกล้อง เลนส์ อารมณ์ และคุณภาพ (เช่น 8k, cinematic lighting) ความยาว 60-120 คำ
- promptTh: เขียนเป็นภาษาไทย ในรูปแบบ "คำสั่งสำหรับวางในแชท AI" ให้พร้อมใช้งานทันที
- titleTh และ descriptionTh เป็นภาษาไทย สั้น กระชับ อ่านแล้วเห็นภาพ
- logline: บรรยายเรื่องราวทั้งหมด 1 ประโยค (ภาษาไทย)`;

  if (input.mode === "video") {
    return `${base}

โหมดวิดีโอ — ผู้ใช้จะนำพร้อมต์ไปสั่ง AI สร้างวิดีโอ "ทีละคลิปต่อเนื่องกัน" ตามเวิร์กโฟลว์นี้:
1. ฉากที่ 1 สร้างจาก "รูปภาพต้นฉบับหรือข้อความ" → promptTh ต้องขึ้นต้นด้วย "จากรูปภาพนี้ ช่วยสร้างวีดีโอ..." (ถ้ามีรูป) หรือ "ช่วยสร้างวีดีโอ..." (ถ้าไม่มีรูป) และ promptEn ต้องเป็น image-to-video prompt ที่อธิบาย "การเคลื่อนไหว" ที่เกิดจากภาพนิ่ง ไม่ใช่แค่อธิบายภาพ
2. ฉากที่ 2 เป็นต้นไป สร้างจาก "คลิปก่อนหน้า" → promptTh ต้องขึ้นต้นด้วย "จากคลิปวีดีโอนี้ ช่วยสร้างวีดีโอต่อเนื่องตามจินตนาการ..." และ promptEn ต้องเป็น continuation prompt ที่บอกชัดเจนว่า "continue seamlessly from the last frame of the previous clip" พร้อมอธิบายเหตุการณ์ใหม่ที่เกิดขึ้น การเคลื่อนไหวของกล้อง และสิ่งที่ต้องคงเดิม (ตัวละคร แสง สี)
- แต่ละฉากยาวประมาณ 8-10 วินาที เน้น "การเคลื่อนไหว" กล้อง ตัวละคร สภาพอากาศ
- continuityNote (ภาษาไทย): อธิบายว่าฉากนี้ต่อจากฉากก่อนหน้าอย่างไร
- เรื่องราวต้องพัฒนาไปข้างหน้าในแต่ละฉาก มีจังหวะ ตึงเครียด-คลาย หรือเซอร์ไพรส์เล็กๆ`;
  }

  return `${base}

โหมดรูปภาพ — ผู้ใช้จะนำพร้อมต์ไปสร้าง "ภาพนิ่งเป็นฉากๆ เรียงลำดับเหมือนสตอรี่บอร์ด":
- promptEn ของทุกฉากเป็น text-to-image prompt ที่สมบูรณ์ในตัวเอง (ใช้แยกกันสร้างทีละภาพได้)
- promptTh ให้ขึ้นต้นด้วย "ช่วยสร้างรูปภาพ..." 
- ทุกฉากเล่าเรื่องเดียวกัน มุมกล้องหลากหลาย (wide shot, close-up, low angle, drone view) เพื่อให้ชุดภาพน่าสนใจ
- continuityNote (ภาษาไทย): อธิบายความสัมพันธ์ของฉากนี้กับฉากก่อนหน้า`;
}

function buildUserPrompt(input: {
  mode: "image" | "video";
  sourceType: "idea" | "image" | "continue";
  idea: string;
  sceneCount: number;
  hasImage: boolean;
}): string {
  const parts: string[] = [];
  if (input.sourceType === "image" && input.hasImage) {
    parts.push(
      "ผู้ใช้แนบ " + "รูปภาพต้นฉบับ" + " มาให้ (ดูในรูปที่แนบ) — ให้วิเคราะห์องค์ประกอบในภาพ (ตัวละคร ยานพาหนะ บรรยากาศ สี แสง สภาพอากาศ) แล้วใช้เป็นจุดเริ่มต้นของเรื่องราวทั้งหมด",
    );
  }
  if (input.sourceType === "continue") {
    parts.push(
      "ผู้ใช้มีคลิป/ภาพจากเรื่องราวเดิมอยู่แล้ว และต้องการ 'ต่อเรื่อง' จากจุดนั้น — บริบทเดิมที่ผู้ใช้ให้มา:",
    );
  } else {
    parts.push("ไอเดีย/เรื่องราวจากผู้ใช้:");
  }
  parts.push(`"""${input.idea}"""`);
  parts.push(
    `จงออกแบบพร้อมต์ทั้งหมด ${input.sceneCount} ฉาก ที่ต่อเนื่องกันเป็นเรื่องราวเดียว (โหมด: ${input.mode === "video" ? "วิดีโอ" : "รูปภาพ"}) ตอบกลับเป็น JSON ตาม schema เท่านั้น`,
  );
  return parts.join("\n\n");
}

const generateInput = z.object({
  mode: z.enum(["image", "video"]),
  sourceType: z.enum(["idea", "image", "continue"]),
  idea: z.string().min(1).max(4000),
  sceneCount: z.number().int().min(1).max(10),
  style: z.string().max(64),
  aspectRatio: z.string().max(16),
  extraDetails: z.string().max(2000).optional(),
  /** data URL (e.g. data:image/jpeg;base64,...) of the reference image, pre-resized by the client */
  imageDataUrl: z.string().max(4_000_000).optional(),
});

export const studioRouter = createRouter({
  generate: authedQuery.input(generateInput).mutation(async ({ ctx, input }) => {
    const kimiGw = getProvider();
    const { models, defaultModelId } = await listModels().catch((err) => {
      throw toTrpcError(err);
    });

    let modelId = defaultModelId;
    const hasImage = Boolean(input.imageDataUrl);
    if (hasImage) {
      const visionModel =
        models.find((m) => m.id === defaultModelId && m.supportsImageIn) ??
        models.find((m) => m.supportsImageIn);
      if (visionModel) modelId = visionModel.id;
    }

    const system = buildSystemPrompt(input);
    const userText =
      buildUserPrompt({ ...input, hasImage }) +
      (input.extraDetails
        ? `\n\nรายละเอียดเพิ่มเติมจากผู้ใช้: """${input.extraDetails}"""`
        : "");

    type Content =
      | string
      | Array<
          | { type: "text"; text: string }
          | { type: "image"; image: string }
        >;
    const userContent: Content =
      hasImage && input.imageDataUrl
        ? [
            { type: "text", text: userText },
            { type: "image", image: input.imageDataUrl },
          ]
        : userText;

    let object: SceneBundle;
    try {
      const result = await generateObject({
        model: kimiGw(modelId),
        schema: bundleSchema,
        system,
        messages: [{ role: "user", content: userContent as never }],
        providerOptions: {
          "kimi-gw": { max_completion_tokens: 8192 },
        },
      });
      object = result.object as SceneBundle;
    } catch (err) {
      throw toTrpcError(err);
    }

    // Normalise scene numbering
    object.scenes = object.scenes
      .slice(0, input.sceneCount)
      .map((s, i) => ({ ...s, scene: i + 1 }));

    const db = getDb();
    const [inserted] = await db.insert(generations).values({
      userId: ctx.user.id,
      mode: input.mode,
      sourceType: input.sourceType,
      title: object.title.slice(0, 255),
      logline: object.logline.slice(0, 512),
      idea: input.idea,
      style: input.style,
      aspectRatio: input.aspectRatio,
      sceneCount: object.scenes.length,
      scenesJson: object.scenes,
    });

    return {
      id: Number((inserted as { insertId?: number | string }).insertId ?? 0),
      ...object,
    };
  }),

  history: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select({
        id: generations.id,
        title: generations.title,
        logline: generations.logline,
        mode: generations.mode,
        sourceType: generations.sourceType,
        sceneCount: generations.sceneCount,
        style: generations.style,
        aspectRatio: generations.aspectRatio,
        createdAt: generations.createdAt,
      })
      .from(generations)
      .where(eq(generations.userId, ctx.user.id))
      .orderBy(desc(generations.createdAt))
      .limit(50);
  }),

  getById: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(generations)
        .where(
          and(eq(generations.id, input.id), eq(generations.userId, ctx.user.id)),
        )
        .limit(1);
      if (!rows[0]) {
        throw new TRPCError({ code: "NOT_FOUND", message: "ไม่พบรายการนี้" });
      }
      return rows[0];
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .delete(generations)
        .where(
          and(eq(generations.id, input.id), eq(generations.userId, ctx.user.id)),
        );
      return { ok: true };
    }),
});
