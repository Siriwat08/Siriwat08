// Shared contracts for the PromptWeaver studio feature (frontend <-> backend).

export type GenerationMode = "image" | "video";
export type SourceType = "idea" | "image" | "continue";

export interface ScenePrompt {
  /** 1-based scene order */
  scene: number;
  /** Short Thai scene title, e.g. "ฝนกระหน่ำกลางทางน้ำท่วม" */
  titleTh: string;
  /** 1-2 sentence Thai description of what happens in the scene */
  descriptionTh: string;
  /** The ready-to-paste English prompt for image/video generators */
  promptEn: string;
  /** Thai command version for chat-based tools (e.g. "จากรูปภาพนี้ ...") */
  promptTh: string;
  /** For video mode: how this scene connects to the previous one */
  continuityNote?: string;
}

export interface SceneBundle {
  title: string;
  logline: string;
  scenes: ScenePrompt[];
}

export const STYLE_OPTIONS = [
  { value: "cinematic", label: "ซีนีมาติกสมจริง" },
  { value: "documentary", label: "สารคดี / ภาพจริง" },
  { value: "anime", label: "อนิเมะญี่ปุ่น" },
  { value: "cartoon3d", label: "การ์ตูน 3D" },
  { value: "fantasy", label: "แฟนตาซีมหัศจรรย์" },
  { value: "retro-film", label: "ฟิล์มย้อนยุค" },
  { value: "cyberpunk", label: "ไซเบอร์พังก์นีออน" },
  { value: "watercolor", label: "สีน้ำศิลปะ" },
] as const;

export const ASPECT_OPTIONS = [
  { value: "16:9", label: "16:9 แนวนอน" },
  { value: "9:16", label: "9:16 แนวตั้ง" },
  { value: "1:1", label: "1:1 จัตุรัส" },
  { value: "4:3", label: "4:3 คลาสสิก" },
] as const;
